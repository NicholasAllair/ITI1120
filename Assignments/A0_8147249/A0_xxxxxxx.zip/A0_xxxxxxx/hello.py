#ITI 1120
#Assignment 0
#Allair, Nicholas
#8147249

print("hello world")
